#imports
import os
import time
import array

#signup
User = input("Username:  ")
Password = input("Password:  ")
PasswordConfirm = input("Confirm:  ")
if PasswordConfirm == Password:
  print("Password Created!")
  time.sleep(1)
  os.system('clear')
else:
  print("Incorrect")
  time.sleep(1)
  os.system('clear')
  print("say a password")
  User = input("Username:  ")
  Password = input("Password:  ")
  PasswordConfirm = input("Confirm:  ")
  if PasswordConfirm == Password:
    print("Password Created!")
    time.sleep(1)
    os.system('clear')
    PasswordConfirmedNow = Password
    UserLogin = input("Username:  ")
    PasswordLogin = input("Password:  ")

    #login
    if UserLogin == User and PasswordLogin == PasswordConfirmedNow:
      print("Logged in!")
    else:
      print("Information is incorrrect")
  else:
    print("Incorrect")
    time.sleep(1)
    os.system('clear')
    print("FAILED")
